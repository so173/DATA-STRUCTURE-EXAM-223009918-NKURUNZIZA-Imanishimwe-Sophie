class FixedOrderArray:
   

    def __init__(self, size):
        self.size = size
        self.orders = [None] * size
        self.current_index = 0

    def add_order(self, order_id, produce, quantity, price):
        if self.current_index < self.size:
            self.orders[self.current_index] = {
                'order_id': order_id,
                'produce': produce,
                'quantity': quantity,
                'price': price
            }
            self.current_index += 1
        else:
            print("Order array is full. Cannot add more orders.")

    def search_order(self, order_id):
        for order in self.orders:
            if order and order['order_id'] == order_id:
                return order
        return None

    def display_orders(self):
        return [order for order in self.orders if order is not None]



order_manager = FixedOrderArray(5)
order_manager.add_order(1, "Tomatoes", 10, 50.0)
order_manager.add_order(2, "Carrots", 5, 20.0)
order_manager.add_order(3, "Potatoes", 15, 30.0)
print("Orders:", order_manager.display_orders())
print("Search for Order ID 2:", order_manager.search_order(2))
order_manager.add_order(4, "Onions", 8, 40.0)
order_manager.add_order(5, "Peppers", 12, 60.0)
order_manager.add_order(6, "Cabbage", 7, 35.0)  
print("Orders After Attempting Overfill:", order_manager.display_orders())
