class FixedOrderArray:
    """
    This class uses a fixed-size array to manage a specific number of orders.
    Each order is stored as a dictionary with keys: 'order_id', 'produce', 'quantity', and 'price'.
    """

    def __init__(self, size):
        self.size = size
        self.orders = [None] * size
        self.current_index = 0

    def add_order(self, order_id, produce, quantity, price):
        if self.current_index < self.size:
            self.orders[self.current_index] = {
                'order_id': order_id,
                'produce': produce,
                'quantity': quantity,
                'price': price
            }
            self.current_index += 1
        else:
            print("Order array is full. Cannot add more orders.")

    def search_order(self, order_id):
        for order in self.orders:
            if order and order['order_id'] == order_id:
                return order
        return None

    def display_orders(self):
        return [order for order in self.orders if order is not None]

    def sort_by_priority(self, priority_key):
        """
        Sort orders based on the specified priority key using Selection Sort.
        """
        n = len(self.orders)
        for i in range(n - 1):
            min_index = i
            for j in range(i + 1, n):
                if self.orders[j] and self.orders[min_index] and self.orders[j][priority_key] < self.orders[min_index][priority_key]:
                    min_index = j
            if self.orders[min_index]:
                self.orders[i], self.orders[min_index] = self.orders[min_index], self.orders[i]


class CircularLinkedListNode:
    """
    Node for the Circular Linked List.
    """

    def __init__(self, data):
        self.data = data
        self.next = None


class CircularLinkedList:
    """
    Circular Linked List to dynamically track produce data.
    """

    def __init__(self):
        self.head = None

    def add_produce(self, produce, quantity, price):
        new_node = CircularLinkedListNode({
            'produce': produce,
            'quantity': quantity,
            'price': price
        })
        if not self.head:
            self.head = new_node
            self.head.next = self.head
        else:
            temp = self.head
            while temp.next != self.head:
                temp = temp.next
            temp.next = new_node
            new_node.next = self.head

    def search_produce(self, produce):
        if not self.head:
            return None
        temp = self.head
        while True:
            if temp.data['produce'].lower() == produce.lower():
                return temp.data
            temp = temp.next
            if temp == self.head:
                break
        return None

    def display_produce(self):
        result = []
        if not self.head:
            return result
        temp = self.head
        while True:
            result.append(temp.data)
            temp = temp.next
            if temp == self.head:
                break
        return result


class TreeNode:
    """
    Node for the hierarchical tree structure.
    """

    def __init__(self, data):
        self.data = data
        self.children = []

    def add_child(self, child):
        self.children.append(child)


class HierarchicalTree:
    """
    Tree structure to represent hierarchical data.
    """

    def __init__(self, root_data):
        self.root = TreeNode(root_data)

    def add_child_to_node(self, parent_data, child_data):
        def _find_node(node, data):
            if node.data == data:
                return node
            for child in node.children:
                found = _find_node(child, data)
                if found:
                    return found
            return None

        parent_node = _find_node(self.root, parent_data)
        if parent_node:
            parent_node.add_child(TreeNode(child_data))
        else:
            print(f"Parent node with data '{parent_data}' not found.")

    def display_tree(self):
        def _display_recursive(node, level=0):
            result = "  " * level + f"- {node.data}\n"
            for child in node.children:
                result += _display_recursive(child, level + 1)
            return result

        return _display_recursive(self.root)


# Example Usage for Hierarchical Tree
tree_manager = HierarchicalTree("Produce")
tree_manager.add_child_to_node("Produce", "Vegetables")
tree_manager.add_child_to_node("Produce", "Fruits")
tree_manager.add_child_to_node("Vegetables", "Tomatoes")
tree_manager.add_child_to_node("Vegetables", "Carrots")
tree_manager.add_child_to_node("Fruits", "Apples")
tree_manager.add_child_to_node("Fruits", "Bananas")
print("Hierarchical Tree Structure:")
print(tree_manager.display_tree())

# Example Usage for Circular Linked List
produce_tracker = CircularLinkedList()
produce_tracker.add_produce("Tomatoes", 50, 2.0)
produce_tracker.add_produce("Carrots", 30, 1.5)
produce_tracker.add_produce("Potatoes", 100, 0.8)
print("Circular Linked List Produce:", produce_tracker.display_produce())
print("Search for Carrots:", produce_tracker.search_produce("Carrots"))

# Example Usage for Selection Sort
order_manager = FixedOrderArray(5)
order_manager.add_order(1, "Tomatoes", 10, 50.0)
order_manager.add_order(2, "Carrots", 5, 20.0)
order_manager.add_order(3, "Potatoes", 15, 30.0)
print("Orders Before Sorting:", order_manager.display_orders())
order_manager.sort_by_priority("price")
print("Orders After Sorting by Price:", order_manager.display_orders())
