class BSTNode:
    """
    Node for the Binary Search Tree.
    """

    def __init__(self, name, quantity):
        self.name = name
        self.quantity = quantity
        self.left = None
        self.right = None


class ProduceBST:
    """
    Binary Search Tree to manage produce data.
    """

    def __init__(self):
        self.root = None

    def insert(self, name, quantity):
        def _insert_recursive(node, name, quantity):
            if not node:
                return BSTNode(name, quantity)
            if name.lower() < node.name.lower():
                node.left = _insert_recursive(node.left, name, quantity)
            elif name.lower() > node.name.lower():
                node.right = _insert_recursive(node.right, name, quantity)
            return node

        self.root = _insert_recursive(self.root, name, quantity)

    def search(self, name):
        def _search_recursive(node, name):
            if not node or node.name.lower() == name.lower():
                return node
            if name.lower() < node.name.lower():
                return _search_recursive(node.left, name)
            return _search_recursive(node.right, name)

        return _search_recursive(self.root, name)

    def delete(self, name):
        def _delete_recursive(node, name):
            if not node:
                return node

            if name.lower() < node.name.lower():
                node.left = _delete_recursive(node.left, name)
            elif name.lower() > node.name.lower():
                node.right = _delete_recursive(node.right, name)
            else:
                # Node with only one child or no child
                if not node.left:
                    return node.right
                elif not node.right:
                    return node.left

                # Node with two children: Get the inorder successor
                successor = self._min_value_node(node.right)
                node.name = successor.name
                node.quantity = successor.quantity
                node.right = _delete_recursive(node.right, successor.name)

            return node

        self.root = _delete_recursive(self.root, name)

    def _min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def in_order_traversal(self):
        def _in_order_recursive(node):
            if not node:
                return []
            return (
                _in_order_recursive(node.left)
                + [{'name': node.name, 'quantity': node.quantity}]
                + _in_order_recursive(node.right)
            )

        return _in_order_recursive(self.root)


# Example Usage
bst_manager = ProduceBST()
bst_manager.insert("Tomatoes", 50)
bst_manager.insert("Carrots", 30)
bst_manager.insert("Potatoes", 100)
print("BST In-Order Traversal:", bst_manager.in_order_traversal())

search_result = bst_manager.search("Carrots")
if search_result:
    print("Found in BST:", {"name": search_result.name, "quantity": search_result.quantity})
else:
    print("Not found in BST.")

bst_manager.delete("Carrots")
print("BST In-Order Traversal After Deletion:", bst_manager.in_order_traversal())
