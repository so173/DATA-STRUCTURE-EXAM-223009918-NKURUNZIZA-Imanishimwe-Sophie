class FixedOrderArray:
    

    def __init__(self, size):
        self.size = size
        self.orders = [None] * size
        self.current_index = 0

    def add_order(self, order_id, produce, quantity, price):
        if self.current_index < self.size:
            self.orders[self.current_index] = {
                'order_id': order_id,
                'produce': produce,
                'quantity': quantity,
                'price': price
            }
            self.current_index += 1
        else:
            print("Order array is full. Cannot add more orders.")

    def search_order(self, order_id):
        for order in self.orders:
            if order and order['order_id'] == order_id:
                return order
        return None

    def display_orders(self):
        return [order for order in self.orders if order is not None]


class CircularLinkedListNode:
    

    def __init__(self, data):
        self.data = data
        self.next = None


class CircularLinkedList:
   

    def __init__(self):
        self.head = None

    def add_produce(self, produce, quantity, price):
        new_node = CircularLinkedListNode({
            'produce': produce,
            'quantity': quantity,
            'price': price
        })
        if not self.head:
            self.head = new_node
            self.head.next = self.head
        else:
            temp = self.head
            while temp.next != self.head:
                temp = temp.next
            temp.next = new_node
            new_node.next = self.head

    def search_produce(self, produce):
        if not self.head:
            return None
        temp = self.head
        while True:
            if temp.data['produce'].lower() == produce.lower():
                return temp.data
            temp = temp.next
            if temp == self.head:
                break
        return None

    def display_produce(self):
        result = []
        if not self.head:
            return result
        temp = self.head
        while True:
            result.append(temp.data)
            temp = temp.next
            if temp == self.head:
                break
        return result


produce_tracker = CircularLinkedList()
produce_tracker.add_produce("Tomatoes", 50, 2.0)
produce_tracker.add_produce("Carrots", 30, 1.5)
produce_tracker.add_produce("Potatoes", 100, 0.8)
print("Circular Linked List Produce:", produce_tracker.display_produce())
print("Search for Carrots:", produce_tracker.search_produce("Carrots"))
